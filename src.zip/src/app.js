
import React from "react";
import ReactDOM from "react-dom";
import {Provider} from "react-redux";
import AppRouter from "./router/AppRouter.js";
import configureStore from "./store/configureStore";
import {addExpense} from "./actions/expenses";
import {setTextFilter} from "./actions/filters";
import getVisibleExpenses from "./selectors/expenses.js";
import "normalize.css/normalize.css";
import "./styles/style.scss";


const store = configureStore();

store.dispatch(addExpense({description:"water bill", amount:100,createdAt:20}));
store.dispatch(addExpense({description:"gas bill", amount:200,createdAt:30}));
store.dispatch(addExpense({description:"rent bill", amount:300,createdAt:10}));



const state = store.getState();
const visibleExpenses = getVisibleExpenses(state.expenses, state.filters);

const jsx = (
  <Provider store={store}>
    <AppRouter/>
  </Provider>
)


ReactDOM.render(jsx, document.getElementById("app"))















// const User = (props)=> {
//   return (
//     <div>
//       <h1>{props.name}</h1>
//     </div>
//   )
// }







// let app = {
//   title:"Indecision",
//   subTitle:"Hahahihi",
//   options:[]
// };
// function appE() {
//   app.options.forEach(function(item) {
//     return item
//   })
// };
// const onFormSubmit = (e)=> {
//   e.preventDefault();
//   const input = e.target.elements.option.value;
//   if (input) {
//     app.options.push(input);
//     e.target.elements.option.value = "";
//
//     renderApp();
//   };
//
// }
// const removeALl = () => {
//   app.options = [];
//   renderApp();
// }
//
// let i = 0;
// const numerate = ()=>{
//   i++;
//   return i;
// }
// const makeDecision = ()=>{
//   let randNumber = (Math.round(Math.random()*app.options.length));
//   console.log(app.options[randNumber]);
// }
//
// const toggle = function () {
//   visibility = !visibility;
//   renderApp()
// }
// const appRoot = document.getElementById("app");
// const app2 = document.getElementById("visibility")
// let visibility = false;
// const renderApp = function () {
//   let template = (
//     <div>
//       <h1>{app.title}</h1>
//       {app.subTitle && <p>{app.subTitle}</p>}
//       {app.options.length >0 ? <p>Here is your options: {app.options}</p> :<p>"No Options"</p> }
//       <p>{app.options.length}</p>
//       <ul>
//         {
//
//           app.options.map((option)=>{
//
//             return <li key={numerate()}>{option}</li>;
//
//           })
//         }
//       </ul>
//       <form onSubmit={onFormSubmit}>
//         <input type="text" name="option"/>
//         <button>Add option</button>
//         <button onClick={removeALl}>Remove All</button>
//         <button disabled={app.options.length ===0} onClick={makeDecision}>Neyniyim</button>
//       </form>
//     </div>
//   );
//
//   let template2 = (
//     <div>
//       <h1>Visibility Toggle</h1>
//       <button onClick={toggle}>{visibility ? "Hide Text" : "show Text"}</button>
//       <p id="salam">{visibility ? "salamalr" : ""}</p>
//     </div>
//   )
//   // ReactDOM.render(template, appRoot);
//   ReactDOM.render(template2, app2);
// }
//
// renderApp();
//
//
//
//
//
//
//
//
//
//
//
//
//
//
// // let user = {
// //   fullname:"rufat aliyev",
// //   age:19,
// //   location:["filippin","merakes","gurscustan"],
// //   hasLived() {
// //    const messages = this.location.map((city) =>{
// //       return this.fullname + "has lived in " + city;
// //     });
// //     return messages
// //   }
// // };
// // console.log(user.hasLived());
// // const getLocation = (location) =>  (location) && <p>Locaition: {location}</p>;
// //
// //
// // let template2 = (
// //   <div>
// //     <h1>{user.fullname ? user.fullname.split(" ")[0] : "Heckim"}</h1>
// //     {(user.age && user.age >=18) && <p>Age: {user.age}</p>}
// //     {getLocation(user.location)}
// //   </div>
// // );
// //
// //
// //
// // const multiplier = {
// //   numbers:[1,2,3,6,5],
// //   multiplyBy: 2,
// //   multiply() {
// //     return this.numbers.map((number) => number*this.multiplyBy);
// //   }
// // }
// // let count = 0;
// // const click = (btn)=> {
// //     if (btn.target.id ==="btn-plus"){
// //     count++;
// //     console.log(btn.id);
// //     renderCounter();
// //   } else {
// //     count--;
// //     console.log(btn.id);
// //     renderCounter();
// //   }
// // }
// //
// //
// // const renderCounter = () => {
// //     const template3 = (
// //       <div>
// //         <h1>Count: {count}</h1>
// //         <button id="btn-plus" className="button" onClick={click}>+1</button>
// //         <button id="btn-minus" className="button" onClick={click}>-1</button>
// //       </div>
// //     );
