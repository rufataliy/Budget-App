import React from "react";
import {BrowserRouter, Route, Switch, Link, NavLink} from "react-router-dom";
import Header from "../components/Header.js";
import ExpenseDashboardPage from "../components/home.js";
import ExpenseCreatePage from "../components/create.js";
import Notfound from "../components/404.js";
import ExpenseEditPage from "../components/edit.js";
import ExpenseHelpPage from "../components/help.js";



const AppRouter =()=>(
  <BrowserRouter>
    <div>
    <Header/>
    <Switch>
      <Route path="/" component={ExpenseDashboardPage} exact={true}/>
      <Route path="/CreateExpense" component={ExpenseCreatePage} />
      <Route path="/Help" component={ExpenseHelpPage} />
      // <Route path="/edit" component={ExpenseEditPage} />
      <Route component={Notfound} />
    </Switch>
    </div>
  </BrowserRouter>
);

export default AppRouter
