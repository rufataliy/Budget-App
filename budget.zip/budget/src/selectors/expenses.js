export default (expenses, {text, sortby, startDate, endDate}) => {
  return expenses.filter((expense)=>{
    const textMatch = expense.description.toLowerCase().includes(text.toLowerCase().trim()) || expense.note.toLowerCase().includes(text.toLowerCase().trim())
    const endDateMatch = typeof startDate !== "number" || expense.createdAt <= startDate;
    const startDateMatch = typeof endDate !== "number" || expense.createdAt >= endDate;
    return startDateMatch && endDateMatch && textMatch;
  }).sort((a,b)=>{
    if (sortby === "date") {
      return a.createdAt < b.createdAt ?1 : -1;

    } else if (sortby === 'amount') {
        return a.amount < b.amount ?1 : -1;
    }
  })
}
