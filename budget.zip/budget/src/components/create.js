import React from "react";
import {BrowserRouter, Route, Switch, Link, NavLink} from "react-router-dom";
import AddExpensePage from "./AddExpensePage"
const ExpenseCreatePage= () => (
  <div>
    <AddExpensePage/>
  </div>
);

export default ExpenseCreatePage
