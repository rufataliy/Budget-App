import React from "react";
import {BrowserRouter, Route, Switch, Link, NavLink} from "react-router-dom";

const Notfound= () => (
  <div>
    404 <Link to="/">go home</Link>
  </div>
);
export default Notfound
