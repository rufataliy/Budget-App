import {createStore} from "redux";

const reset = ({count}={})=>({
  type:"RESET",
  count:0
})
const set = ({count}={})=>({
  type:"SET",
  count: count
})
const store = createStore((state = {count:0},action) => {
  switch (action.type) {

    case "INCREMENT":
    const decby = typeof action.by === "number"? action.by :1;
    return {
      count:state.count + decby
    }
    case "DECREMENT":
    const by = typeof action.by === "number" ? action.by :1;
      return {
        count:state.count - by
      }
    case "RESET":
      return {
        count:action.count
      }
    case "SET":
      return {
        count:action.count
      }

    default:
      return state;
  }

});
const unsubscribe = store.subscribe(()=>{
  console.log(store.getState());
})

store.dispatch({
  type:"INCREMENT",
  by: 2
})

store.dispatch({
  type:"INCREMENT"
})
store.dispatch(reset())

store.dispatch({
  type:"DECREMENT",
  by: 10
})
store.dispatch(set({count:12}))
