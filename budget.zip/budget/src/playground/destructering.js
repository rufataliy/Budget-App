// object destructering

// console.log("destructering");
//
// const person = {
//   name: "andrew",
//   age:26,
//   location:{
//     city:"2",
//     temp:88
//   }
// };
//
// const {name,age,} = person;
// const {city:seher = "baku",temp} = person.location
// if (temp) {
//   console.log(`${seher} is ${person.age}.`);
// }

// const book = {
//   title: "ego is the enemy",
//   author: "Ryan Holiday",
//   publisher: {
//     name:undefined
//   }
// };
// const {name: publisherName = "no publisher"} = book.publisher;
// console.log(publisherName);

// array destructering

const address = ["1299 s juniper street", "philadelphia"];
const [street, city, state = "new york", zip] = address;
console.log(`you are in ${city}, ${state}`);

const item = [, "2$", "2.50$", "2.75$"];

const [itemName = "iced", small, medium, large] = item;

console.log(`A medium ${itemName} costs ${medium}`);
